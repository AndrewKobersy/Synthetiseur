/**
 * Description:
 * Cette classe permet de creer la barre de menu qui donne le choix a 
 * l'utilisateur de choisir le mode de jeu. Il a le choix entre le mode souris
 * et le mode clavier
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 */

package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import audio.AudioConstantes;

public class BarreMenus extends JMenuBar {

	// Attributs privees de la classe BarreMenus
	private PanneauPrincipal panneauPrincipal;
	private JMenuBar barreDeMenu;
	private JMenu menu;
	private JMenuItem modeClavier;
	private JMenuItem modeSouris;

	/*
	 * **********************************
	 * LE CONSTRUCTEUR
	 * **********************************
	 */
	public BarreMenus(PanneauPrincipal panneauPrincipal) {

		this.panneauPrincipal = panneauPrincipal;

		// Appel a la fonction qui initialise la barre de menu
		initComposantsBarreMenu();
	}
	
	/*
	 * ***********************************
	 * LES METHODES
	 * ***********************************
	 */
	
	/**
	 * Methode qui permet de creer la barre de menu
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void creerBarreMenu() {

		// Creation de la barre de menu
		barreDeMenu = new JMenuBar();
	}

	/**
	 * Methode qui permet de creer le menu
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void creerMenu(String titre) {

		// Creation du menu
		menu = new JMenu(titre);
	}

	/**
	 * Methode qui permet de creer les deux options du menu (mode souris et mode
	 * clavier)
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void creerItemMenu() {

		// Creation du bouton mode clavier
		modeClavier = new JMenuItem("Clavier");

		// Creattion du bouton mode souris
		modeSouris = new JMenuItem("Souris");
	}

	/**
	 * Methode qui ajoute les 2 modes au menu
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void ajouterItemMenu() {

		// On ajoute le bouton mode clavier dans le menu
		menu.add(modeSouris);

		// On ajoute le bouton mode souris dans le menu
		menu.add(modeClavier);
	}

	/**
	 * Methode qui permet d'ajouter le bouton menu dans la barre de menu
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void ajouterMenu() {

		// On ajoute le bouton menu dans la barre de menu
		add(menu);
	}

	/**
	 * Methode qui initialise la barre de menu
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void initComposantsBarreMenu() {

		// Appel des fonctions qui creer la barre du menu
		creerBarreMenu();
		creerMenu("Mode de jeu");
		creerItemMenu();
		ajouterMenu();
		ajouterItemMenu();
		ajouterEcouteurBarreMenuItem();
	}

	/**
	 * Methode qui permet d'ajouter un ecouteur pour chacun des items de la barre 
	 * du menu
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void ajouterEcouteurBarreMenuItem() {

		// ajout des �couteurs pour les boutons
		EcouteurBarreMenuItem action = new EcouteurBarreMenuItem();
		modeSouris.addActionListener(action);
		modeClavier.addActionListener(action);
	}

	/*
	 * ************************************** 
	 * CLASSE PRIVEE
	 * **************************************
	 */
	private class EcouteurBarreMenuItem implements ActionListener {

		public void actionPerformed(ActionEvent e) {

			// On retient le choix de l'utilisateur
			JMenuItem choixMenu = (JMenuItem) e.getSource();

			// Si on choisi le mode clavier
			if (choixMenu == modeClavier) {

				// On met le mode de jeu pour mode souris
				panneauPrincipal.setMode(ConstantesMode.MODE_CLAVIER);

				// On montre une message
				JOptionPane.showMessageDialog(null, "Vous etes en mode clavier");

			}
			// Sinon si on choisi le mode souris
			else if (choixMenu == modeSouris) {

				// On met le mode de jeu pour le mode clavier
				panneauPrincipal.setMode(ConstantesMode.MODE_SOURIS);

				// On montre une message
				JOptionPane.showMessageDialog(null, "Vous etes en mode souris");

			}
			
			//On valide les composantes
			validate();

		}

	}

}
