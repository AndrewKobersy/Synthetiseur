/**
 * Description:
 * Cette classe permet de creer le panneau d'enregistrement pour enregistrer 
 * la melodie jouer sur le synthetiseur
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 */
package gui;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import audio.ModuleAudio;

public class PanneauEnregistrement extends JPanel{
	
	//Attributs privees de la classe PanneauEnregistrement
	private JButton demarrage;
	private JButton arret;
	private JButton jouer;
	private ArrayList<String> melodie;
	private ModuleAudio son;
	private boolean caFilme;
	private PanneauPrincipal panneauPrincipal;
	private PanneauControle controle;
	
	/*
	 * ********************************
	 * LE CONSTRUCTEUR
	 * ********************************
	 */
	public PanneauEnregistrement(ModuleAudio son,PanneauPrincipal panneauPrincipal) {
		
		this.son=son;
		this.panneauPrincipal=panneauPrincipal;
		
		//On appel la methode qui cree le panneau d'enregistrement
		initPanneauEnregistrement();
	}
	
	/*
	 * ********************************
	 * LES METHODES 
	 * ********************************
	 */
	
	/**
	 * Methode qui permet d'initiliaser le panneau d'enregistrement
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void initPanneauEnregistrement() {
		
		//On instancie la collection pour l'enregistrement
		melodie=new ArrayList<String>();
		
		//On appel les methodes qui creent le panneau d'enregistrement
		creerPanneauEnregistrement();
		creerEtAjouterBoutonAuPanneau();
		ajouterEcouteurEnregistrement();
		
	}
	
	/**
	 * Methode qui permet d'instancier un panneau d'enregistrement
	 * 
	 * @param aucun parametre
	 * @return auncune valeur de retour
	 */
	public void creerPanneauEnregistrement() {
		
		//On change la couleur de fond su panenau d'enregistrement
		setBackground(Color.LIGHT_GRAY);
	}
	
	/**
	 * Methode qui permet de creer et d'ajouter des boutons au panneau
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void creerEtAjouterBoutonAuPanneau() {
		
		//Instanciation des boutons
		demarrage = new JButton("R");
		arret = new JButton("||");
		jouer = new JButton(">");
		
		/*
		 * On change la couleur des boutons
		 * ROUGE: Enregistrer
		 * JAUNE: Arret
		 * VERT: Jouer
		 */
		demarrage.setBackground(Color.RED);
		arret.setBackground(Color.YELLOW);
		jouer.setBackground(Color.GREEN);
		
		//Ajouter les boutons au panneau d'enregistrement
		add(demarrage);
		add(arret);
		add(jouer);
	}
	
	/**
	 * Methode qui permet d'ajouter un ecouteur au bouton
	 * 
	 * @param aucun parametre 
	 * @return aucune valeur de retour 
	 */
	public void ajouterEcouteurEnregistrement() {
		
		//On cree l'ecouteur
		EcouteurBoutonEnregistrement enregistrement = 
											new EcouteurBoutonEnregistrement();
		
		//On ajoute les ecouteurs aux boutons
		demarrage.addActionListener(enregistrement);
		arret.addActionListener(enregistrement);
		jouer.addActionListener(enregistrement);
	}
	
	/**
	 * Methode qui permet d'ajouter une note a la collection de note
	 * 
	 * @param noteJouer la note jouer sur le piano
	 * @return aucune valeur de retour
	 */
	public void ajouterNoteMelodie(String noteJouer) {
		
		//On ajoute la note a la collection
		melodie.add(noteJouer);
	}
	
	/*
	 * **************************
	 * LES ACCESSEURS
	 * **************************
	 */
	
	/**
	 * Methode qui permet d'avoir la valeur qui commence l'enregistrement
	 * 
	 * @param aucun parametre
	 * @return caFilme 
	 */
	public boolean getCaFilme() {
		
		//On retourne la variable 
		return caFilme;
	}
	
	/*
	 * *******************
	 * LES MUTATEURS
	 * *******************
	 */
	
	/**
	 * Mutateur qui permet de donner un panneau de controle
	 * 
	 * @param controle le panneau de controle
	 * @return aucune valeur de retour
	 */
	public void setPanneauControle(PanneauControle controle) {
		
		this.controle=controle;
		
	}
	
	/**
	 * Mutateur qui permet de donner une valeur a la variable caFilme
	 * 
	 * @param caFilme
	 * @return aucune valeur de retour 
	 */
	public void setCaFilme(boolean caFilme) {
		
		this.caFilme=caFilme;
	}
	
	/**
	 * Methode qui permet de jouer la melodie enregistrer dans la collection
	 * de l'enregistrement
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void jouerMelodie() {
		
		//On parcourt la collection
		for(int i=0;i<melodie.size();++i) {
			
			//On joue chacune des notes enregistrees
			son.jouerUneNote(melodie.get(i));
			
			//On essaye de faire une pause
			try {
				Thread.sleep(500);
			
			//On montre la trace
			}catch(InterruptedException e){
				
				e.printStackTrace();
			}
			
			//On joue un silence
			son.jouerUnSilence();
		}
	}
	
	/*
	 * *******************
	 * CLASSE PRIVEE
	 * *******************
	 */
	
	private class EcouteurBoutonEnregistrement implements ActionListener {
		
		/**
		 * Methode qui permet de faire une action lorsqu'on appuie sur des
		 * boutons
		 * 
		 * @param e un ActionEvent
		 * @return aucune valeur de retour
		 */
		public void actionPerformed(ActionEvent e){
			
			//Si l'utilisateur demarre l'enregistrement
			if(e.getSource()==demarrage) {
				
				//On efface l'ancienne melodie
				melodie.clear();
				
				//On commence a enregistrer
				caFilme=true;
			}
			//Si l'utilisateur rejoue la melodie
			else if(e.getSource()==jouer) {
				
				//Si l'utilisateur n'a pas enregistrer de melodie
				if(melodie.isEmpty()){
					
					//On affiche un message d'erreur
					JOptionPane.showMessageDialog(null
												,ConstantesMode.MESSAGE_ERREUR);
				}
				//Sinon
				else{
					
					//On joue la melodie enregistree
					jouerMelodie();
				}
				
			}
			//Sinon si l'utilisateur choisi d'arreter l'enregistrement
			else if(e.getSource()==arret){
				
				//On arrete d'enregistrer
				caFilme=false;
			}
			
			//On met le fcous dans les 2 panneaux
			panneauPrincipal.getControle().getPanneauControle().requestFocusInWindow();	
		}
		
	}
	
}
