/**
 * Description:
 * Cette classe permet de creer la fenetre pour le synthetiseur, toutes les 
 * autres composantes sont ajoutees dans cette fenetre
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 */

package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

import audio.AudioConstantes;

public class GUISynthetiseur extends JFrame implements Runnable {

	// Attributs privees de la classe GUISynthetiseur
	private PanneauPrincipal panneau;
	private int volume;
	private int octave;

	/*
	 * ***********************************
	 *  LE CONSTRUCTEUR
	 * ***********************************
	 */
	public GUISynthetiseur(int volume, int octave) {

		// On donne un nom
		super("Synthetiseur");

		this.volume = volume;

		this.octave = octave;

		// Creation du cadre
		initSynthetiseur();

	}

	/*
	 * ***************************************
	 *  METHODE IMPLEMENTER
	 * ***************************************
	 */
	public void run() {

		// On instancie le panneau principal
		panneau = new PanneauPrincipal(volume, octave);

		// On ajoute le panneau au cadre
		getContentPane().add(panneau);

		// On ajoute la barre de menu au cadre
		setJMenuBar(new BarreMenus(panneau));

		// On valide les composantes
		validate();
	}

	/*
	 * ***************************************** 
	 * LES METHODES
	 * *****************************************
	 */

	/**
	 * Methode qui permet d'initialiser un cadre pour le synthetiseur
	 * 
	 * @param aucun param
	 * @return aucun retour
	 */
	public void initSynthetiseur() {

		// On clique sur X pour fermer le synthetiseur
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// On cree les dimensions du cadre
		setMinimumSize(new Dimension(600, 295));

		// On met une location pour le cadre
		setLocation(400, 400);

		// La fenetre ouvre en plein ecran
		setExtendedState(MAXIMIZED_BOTH);

		// On fait apparaitre le cadre
		setVisible(true);
	}

}
