/**
 * Description:
 * Cette classe permet de creer le panneau de clavier qui contient les touches 
 * du piano
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 */

package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;

import audio.AudioConstantes;
import audio.ModuleAudio;

public class PanneauClavier extends JPanel {

	// Attributs privees de la classe PanneauClavier
	private ModuleAudio son;
	private int octaveCourante;
	private int mode;
	private ToucheClavier[] toucheClavier;
	private PanneauEnregistrement enregistrement;

	// On retient la hauteur et la largeur de chacune des touches du claviers
	int hauteur = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight()
												/ ConstantesMode.LARGEUR_TOUCHE;

	int largeur = (int) (Toolkit.getDefaultToolkit().getScreenSize().getWidth()
											/ ConstantesMode.HAUTEUR_TOUCHE);

	/*
	 * ********************************** 
	 * LE CONSTRUCTEUR
	 * **********************************
	 */
	public PanneauClavier(int octaveCourante, ModuleAudio son, PanneauEnregistrement enregistrement) {

		this.octaveCourante = octaveCourante;
		this.son = son;
		this.enregistrement = enregistrement;

		// On instancie le tableau des touches
		toucheClavier = new ToucheClavier[ConstantesMode.NOMBRE_TOUCHES_CLAVIER];

		// On change la couleur du panneau de clavier
		setBackground(Color.BLACK);

		// On appel la methode qui cree le panneau de clavier
		initPanneauClavier();

		// On valide les composantes
		validate();
	}

	/*
	 * *********************************
	 *  LES METHODES
	 * *********************************
	 */

	/**
	 * Methode qui permet d'initialiser le panneau de clavier avec les touches
	 * correspondantes
	 * 
	 * @param aucune valeur de retour
	 * @return aucune valeur de retour
	 */
	public void initPanneauClavier() {

		// On cree les touches du clavier
		creerToucheClavier();

		// On ajoute les touches au panneau de clavier
		ajouterToucheAuPanneauClavier(toucheClavier);

		// On cree et on ajoute les ecouteurs a chacune des touches du clavier
		creerEtAjouterMouseListener();
	}

	/**
	 * Methode qui permet de creer des touches de clavier et les met dans un tableau
	 * de type ToucheClavier
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void creerToucheClavier() {

		// On instancie chacune des touches du clavier
		ToucheClavier toucheDo = new ToucheClavier(AudioConstantes.DO
													, Color.WHITE
													, octaveCourante
													, Color.BLACK
													, hauteur, largeur);
		ToucheClavier toucheDoDiese = new ToucheClavier(AudioConstantes.DO_DIESE
														, Color.BLACK
														, octaveCourante
														, Color.WHITE
														, hauteur, largeur);
		ToucheClavier toucheRe = new ToucheClavier(AudioConstantes.RE
													, Color.WHITE
													, octaveCourante
													, Color.BLACK
													, hauteur, largeur);
		ToucheClavier toucheReDiese = new ToucheClavier(AudioConstantes.RE_DIESE
														, Color.BLACK
														, octaveCourante
														, Color.WHITE
														, hauteur, largeur);
		ToucheClavier toucheMi = new ToucheClavier(AudioConstantes.MI
													, Color.WHITE
													, octaveCourante
													, Color.BLACK
													, hauteur, largeur);
		ToucheClavier toucheFa = new ToucheClavier(AudioConstantes.FA
													, Color.WHITE
													, octaveCourante
													, Color.BLACK
													, hauteur, largeur);
		ToucheClavier toucheFaDiese = new ToucheClavier(AudioConstantes.FA_DIESE
														, Color.BLACK
														, octaveCourante
														, Color.WHITE
														, hauteur, largeur);
		ToucheClavier toucheSol = new ToucheClavier(AudioConstantes.SOL
													, Color.WHITE
													, octaveCourante
													, Color.BLACK
													, hauteur, largeur);
		ToucheClavier toucheSolDiese = new ToucheClavier(AudioConstantes.SOL_DIESE
														, Color.BLACK
														, octaveCourante
														, Color.WHITE
														, hauteur, largeur);
		ToucheClavier toucheLa = new ToucheClavier(AudioConstantes.LA
													, Color.WHITE
													, octaveCourante
													, Color.BLACK
													, hauteur, largeur);
		ToucheClavier toucheLaDiese = new ToucheClavier(AudioConstantes.LA_DIESE
														, Color.BLACK
														, octaveCourante
														, Color.WHITE, hauteur
														, largeur);
		ToucheClavier toucheSi = new ToucheClavier(AudioConstantes.SI
													, Color.WHITE
													, octaveCourante
													, Color.BLACK
													, hauteur
													, largeur);
		ToucheClavier toucheDo_fin = new ToucheClavier(AudioConstantes.DO
														, Color.WHITE
														, octaveCourante + 1
														, Color.BLACK
														, hauteur, largeur);

		// On ajoute chacune des touches au tableau de touche
		toucheClavier[0] = toucheDo;
		toucheClavier[1] = toucheDoDiese;
		toucheClavier[2] = toucheRe;
		toucheClavier[3] = toucheReDiese;
		toucheClavier[4] = toucheMi;
		toucheClavier[5] = toucheFa;
		toucheClavier[6] = toucheFaDiese;
		toucheClavier[7] = toucheSol;
		toucheClavier[8] = toucheSolDiese;
		toucheClavier[9] = toucheLa;
		toucheClavier[10] = toucheLaDiese;
		toucheClavier[11] = toucheSi;
		toucheClavier[12] = toucheDo_fin;

		// On valide les composantes
		validate();

	}

	/**
	 * Methode qui permet d'ajouter les touches de clavier au panneau de clavier
	 * 
	 * @param tabTouche un tableau contenant les touches du piano
	 * @return aucune valeur de retour
	 */
	public void ajouterToucheAuPanneauClavier(ToucheClavier[] tabTouche) {

		// On efface ce qu'il y a dans le tableau
		removeAll();

		// On parcourt le tableau des touches
		for (int i = 0; i < tabTouche.length; ++i) {

			// On ajoute les touches au panneau
			add(tabTouche[i]);

		}

		// On valide les composantes
		validate();
	}

	/**
	 * Methode qui permet de creer et d'ajouter un ecouteur pour chacune 
	 * des touches
	 * 
	 * @param aucun parametre
	 * @return aucune valeur de retour
	 */
	public void creerEtAjouterMouseListener() {

		// On cree un objet du meme type que l'ecouteur de la souris
		EcouteurModeSouris ecouteurTouche = new EcouteurModeSouris();

		// On parcourt le tableau contenant les touches du clavier
		for (int i = 0; i < toucheClavier.length; ++i) {

			// On ajoute l'ecouteur a chacune des touches
			toucheClavier[i].addMouseListener(ecouteurTouche);

		}
	}

	/*
	 * ****************************** 
	 * LES MUTATEURS
	 *  ******************************
	 */

	/**
	 * Mutateur de la classe PanneauClavier qui permet de mettre le mode de jeu
	 * 
	 * @param modeDeJeu qui est de type int
	 * @return aucune valeur de retour
	 */
	public void setMode(int mode) {

		this.mode = mode;
	}

	/**
	 * Mutateur pour l'octave de la note
	 * 
	 * @param l'octave courante
	 * @return aucune valeur de retour
	 */
	public void setOctave(int octaveCourante) {

		this.octaveCourante = octaveCourante;

		initPanneauClavier();
	}

	/*
	 * ********************************** 
	 * LES ACCESSEURS
	 * **********************************
	 */

	/**
	 * Accesseur qui permet de retourner le tableau contenant les touches du clavier
	 * 
	 * @param aucun parametre
	 * @return retourne le tableau de touche
	 */
	public ToucheClavier[] getTableauTouche() {

		return toucheClavier;
	}

	/*
	 * **************************************
	 *  CLASSE PRIVEE
	 * **************************************
	 */
	private class EcouteurModeSouris implements MouseListener {

		public void mouseClicked(MouseEvent e) {
		}

		/**
		 * Methode qui permet de creer le son de la note lorsque l'utilisateur enfonce
		 * la touche
		 * 
		 * @param e un mouse event qui lit l'action
		 * @return aucune valeur de retour
		 */
		public void mousePressed(MouseEvent e) {

			// On retient le clic de la souris
			ToucheClavier touche = (ToucheClavier) e.getSource();

			// Si c'est le mode souris
			if (mode == ConstantesMode.MODE_SOURIS) {

				// On joue la note
				son.jouerUneNote(touche.getNote().getText());

				// Si l'utilisateur enregistre la melodie
				if (enregistrement.getCaFilme()) {

					// On ajoute les notes dans la collection de l'enregistrement
					enregistrement.ajouterNoteMelodie(touche.getNote().getText());
				}
			}
		}

		/**
		 * Methode qui permet de creer un silence lorsque l'utilisateur relache la
		 * touche
		 * 
		 * @param un mouse event qui lit l'action
		 * @return aucune valeur de retour
		 */
		public void mouseReleased(MouseEvent e) {

			// Si l'utilssateur est en mode souris
			if (mode == ConstantesMode.MODE_SOURIS) {

				// On joue un silence
				son.jouerUnSilence();
			}
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}

	}

}
