/**
 * Description:
 * Cette classe contient toutes les constantes qui sont utilises par 
 * le synthetiseur
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 */

package gui;

public class ConstantesMode {
	
	//Les constantes
	public static final int MODE_SOURIS=1;
	public static final int MODE_CLAVIER=2;
	public static final String MESSAGE_ERREUR= "Vous n'avez enregistrez aucune"
												+ " melodie! ";
	public static final int NOMBRE_TOUCHES_CLAVIER=13;
	public static final int LARGEUR_TOUCHE=5;
	public static final int HAUTEUR_TOUCHE=38;
}
